package ir.queueradar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { QueueRadarApp() } }
}

data class SymbolState(val symbol:String,val price:Int,val queue:Long,val queueDelta:Int,val trades:Int,val risk:Int,val state:String)

class RadarViewModel: ViewModel() {
    var symbols by mutableStateOf(listOf(
        SymbolState("وتجارت",951,12400000,-18,1832,34,"صف خرید سالم"),
        SymbolState("فملی",4230,8700000,-41,2640,72,"در حال تخلیه"),
        SymbolState("خودرو",3380,21500000,-63,5210,91,"احتمال شکست صف"),
        SymbolState("شستا",2145,6300000,8,1140,22,"صف خرید قوی")
    )); private set
    var lastUpdate by mutableStateOf("اکنون"); private set
    init { viewModelScope.launch { while(true){ delay(4000); symbols=symbols.map { s -> val r=(s.risk+Random.nextInt(-2,4)).coerceIn(0,100); s.copy(risk=r,queueDelta=(s.queueDelta+Random.nextInt(-3,4)).coerceIn(-100,100),state=when { r>=85->"احتمال شکست صف"; r>=60->"در حال تخلیه"; r>=35->"تحت نظر"; else->"صف خرید سالم" }) }; lastUpdate="چند ثانیه پیش" } } }
}

@Composable fun QueueRadarApp(vm:RadarViewModel=viewModel()) { var tab by remember{mutableIntStateOf(0)}; MaterialTheme { Scaffold(topBar={TopAppBar(title={Text("صف‌بان ایران",fontWeight=FontWeight.Bold)},actions={Text("● زنده",color=MaterialTheme.colorScheme.primary,modifier=Modifier.padding(end=16.dp))})},bottomBar={NavigationBar{listOf("رادار","واچ‌لیست","هشدارها").forEachIndexed{i,t->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={},label={Text(t)})}}}){p->when(tab){0->RadarScreen(vm,p);1->WatchlistScreen(vm,p);else->AlertsScreen(p)}} } }
@Composable fun RadarScreen(vm:RadarViewModel,p:PaddingValues){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.padding(p)){item{Text("رادار صف خرید",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("به‌روزرسانی: ${vm.lastUpdate}")};items(vm.symbols){SymbolCard(it)}}}
@Composable fun SymbolCard(s:SymbolState){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(s.symbol,fontWeight=FontWeight.Bold);Text(s.state,fontWeight=FontWeight.Bold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("صف: ${s.queue/1000000.0}M");Text("ریسک شکست: ${s.risk}%");Text("معاملات: ${s.trades}")};LinearProgressIndicator(progress={s.risk/100f},modifier=Modifier.fillMaxWidth());if(s.risk>=85)Text("هشدار: احتمال بالای شکست صف",fontWeight=FontWeight.Bold)else if(s.risk>=60)Text("هشدار: صف در حال ضعیف‌شدن است")}}}
@Composable fun WatchlistScreen(vm:RadarViewModel,p:PaddingValues){Column(Modifier.padding(p).padding(16.dp)){Text("واچ‌لیست",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));vm.symbols.forEach{Row(Modifier.fillMaxWidth().padding(vertical=8.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(it.symbol);Text("${it.risk}%")}}}}
@Composable fun AlertsScreen(p:PaddingValues){Column(Modifier.padding(p).padding(16.dp)){Text("هشدارها",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Text("هشدار — خودرو: احتمال شکست صف");Text("هشدار — فملی: تخلیه صف");Spacer(Modifier.height(20.dp));Text("نسخه MVP: فید بازار در این نسخه شبیه‌سازی شده است.")}}
